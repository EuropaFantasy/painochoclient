#pragma once

#include "../../../base/minecraft.hpp"

class Vanilla189 : public Minecraft {
public:
    explicit Vanilla189(jobject obj, JNIEnv *env, jvmtiEnv *tiEnv);
};