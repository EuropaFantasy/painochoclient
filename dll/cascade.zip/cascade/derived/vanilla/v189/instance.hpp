#pragma once

#include "minecraft.hpp"

#include <memory>

std::shared_ptr<Vanilla189> vanilla189(JNIEnv *env, jvmtiEnv *tiEnv) {
    jclass cls = env->FindClass("ave");
    jfieldID fID = env->GetStaticFieldID(cls, "S", "Lave;");
    jobject obj = env->GetStaticObjectField(cls, fID);
    return std::make_shared<Vanilla189>(obj, env, tiEnv);
}