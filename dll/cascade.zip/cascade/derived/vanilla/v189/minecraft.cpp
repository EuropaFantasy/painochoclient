#include "minecraft.hpp"

Vanilla189::Vanilla189(jobject obj, JNIEnv *env, jvmtiEnv *tiEnv) : Minecraft(obj, env, tiEnv) {
    m_rightClickDelayFID = getEnv()->GetFieldID(getClass(), "ap", "I");
}