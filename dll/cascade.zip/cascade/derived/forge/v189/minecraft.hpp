#pragma once

#include "../../../base/minecraft.hpp"

class Forge189 : public Minecraft {
public:
    explicit Forge189(jobject obj, JNIEnv *env, jvmtiEnv *tiEnv);
};