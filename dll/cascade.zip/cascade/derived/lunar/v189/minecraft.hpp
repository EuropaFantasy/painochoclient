#pragma once

#include "../../../base/minecraft.hpp"

class Lunar189 : public Minecraft {
public:
    explicit Lunar189(jobject obj, JNIEnv *env, jvmtiEnv *tiEnv);
};