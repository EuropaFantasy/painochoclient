#include "minecraft.hpp"

Lunar189::Lunar189(jobject obj, JNIEnv *env, jvmtiEnv *tiEnv) : Minecraft(obj, env, tiEnv) {
    m_rightClickDelayFID = getEnv()->GetFieldID(getClass(), "rightClickDelayTimer", "I");
}