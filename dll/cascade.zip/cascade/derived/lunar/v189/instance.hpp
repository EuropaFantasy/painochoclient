#pragma once

#include "minecraft.hpp"

std::shared_ptr<Lunar189> lunar189(JNIEnv *env, jvmtiEnv *tiEnv) {
    jclass cls = findClass("net/minecraft/client/Minecraft", env, tiEnv);
    jfieldID fID = env->GetStaticFieldID(cls, "theMinecraft", "Lnet/minecraft/client/Minecraft;");
    jobject obj = env->GetStaticObjectField(cls, fID);

    return std::make_shared<Lunar189>(obj, env, tiEnv);
}