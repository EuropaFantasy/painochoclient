#pragma once

#include "object.hpp"

#include <memory>

class Minecraft : public Object {

protected:
    jfieldID m_rightClickDelayFID{};


public:
    explicit Minecraft(jobject obj, JNIEnv *env, jvmtiEnv *tiEnv);
    virtual void setRightClickDelay(int delay);
};