#include "minecraft.hpp"

Minecraft::Minecraft(jobject obj, JNIEnv *env, jvmtiEnv *tiEnv) : Object(obj, env, tiEnv) {
}

void Minecraft::setRightClickDelay(int delay) {
    getEnv()->SetIntField(getObj(), m_rightClickDelayFID, delay);
}