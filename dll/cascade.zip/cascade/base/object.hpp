#pragma once

#include <string>

#include <jni.h>
#include <jvmti.h>

class Minecraft;

class Object {
    jclass m_cls;
    jobject m_obj;
    JNIEnv *m_env;
    jvmtiEnv *m_tiEnv;

public:
    Object(jobject obj, JNIEnv *env, jvmtiEnv *tiEnv);

    [[nodiscard]] jclass getClass() const;

    [[nodiscard]] jobject getObj() const;

    [[nodiscard]] JNIEnv *getEnv() const;
};