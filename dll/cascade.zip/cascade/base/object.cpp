#include "object.hpp"
#include "minecraft.hpp"

Object::Object(jobject obj, JNIEnv *env, jvmtiEnv *tiEnv) : m_obj(obj), m_env(env), m_tiEnv(tiEnv) {
    m_cls = getEnv()->GetObjectClass(m_obj);
}

jclass Object::getClass() const
{
  return m_cls;
}

jobject Object::getObj() const
{
  return m_obj;
}

JNIEnv *Object::getEnv() const
{
  return m_env;
}