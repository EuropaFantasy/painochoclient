#pragma once

enum class Client {
    Vanilla, Forge, Lunar
};